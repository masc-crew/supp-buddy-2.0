create
    definer = rdsadmin@localhost procedure rds_start_upgrade_prechecks(IN targetEngineName text, IN targetEngineVersion text)
BEGIN
  DECLARE v_engine_version TEXT;
  DECLARE v_called_by_user TEXT;
  DECLARE most_recent_action TEXT;
  DECLARE most_recent_status TEXT;
  DECLARE sql_logging BOOLEAN;

  SELECT @@sql_log_bin, user(), version() INTO sql_logging, v_called_by_user, v_engine_version;

  BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
    SET @@sql_log_bin=OFF;
    START TRANSACTION;

    
    INSERT INTO mysql.rds_history(called_by_user, action, mysql_version) VALUES (v_called_by_user, 'start prechecks', v_engine_version);
    COMMIT;

    SELECT action, status INTO most_recent_action, most_recent_status FROM mysql.rds_upgrade_prechecks ORDER BY start_timestamp DESC LIMIT 1;

    
    IF targetEngineName <> 'mysql'
    THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only mysql target engine is supported';
    END IF;

    
    IF targetEngineVersion IS NULL OR targetEngineVersion = ''
    THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Target engine version is required';
    
    ELSEIF NOT targetEngineVersion REGEXP '^[0-9]+(\.[0-9]+){2}$'
    THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Target engine version must be in X.X.X format';
    END IF;

    IF most_recent_action = 'engine upgrade' AND most_recent_status IN ('in progress')
    THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot call procedure while engine upgrade in progress.';
    ELSEIF most_recent_action = 'precheck' AND most_recent_status IN ('in progress')
    THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Upgrade prechecks in progress. Please stop currently running prechecks using mysql.rds_stop_upgrade_prechecks()';
    ELSE
      START TRANSACTION;
      INSERT INTO mysql.rds_upgrade_prechecks(action,status,engine_version,target_engine_name,target_engine_version) VALUES ('precheck','pending',v_engine_version,targetEngineName,targetEngineVersion);
      
      INSERT INTO mysql.rds_history(called_by_user, action, mysql_version) VALUES (v_called_by_user, 'start prechecks:ok', v_engine_version);
      COMMIT;
      SELECT 'Starting upgrade prechecks.' as 'Success';
    END IF;
    SET @@sql_log_bin=sql_logging;
  END;

END;

