create
    definer = rdsadmin@localhost procedure rds_show_upgrade_prechecks_status()
BEGIN
  SELECT action, status, engine_version, target_engine_name, target_engine_version, start_timestamp, last_timestamp, prechecks_completed, prechecks_remaining
  FROM mysql.rds_upgrade_prechecks WHERE action IN ('precheck', 'engine upgrade') ORDER BY start_timestamp DESC LIMIT 1;
END;

